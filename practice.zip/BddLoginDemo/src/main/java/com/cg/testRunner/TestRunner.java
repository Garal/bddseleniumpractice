package com.cg.testRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin={"pretty","html:htmlop/html-output"},features= {"classpath:features"},
				 glue= {"com.cg.BddLoginDemo"})
public class TestRunner {

}
