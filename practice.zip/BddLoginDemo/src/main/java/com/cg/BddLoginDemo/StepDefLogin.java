package com.cg.BddLoginDemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pageFactory.PageFactoryLogin;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {

	private PageFactoryLogin fact;
	private WebDriver driver;

	@Given("^check user name$")
	public void check_user_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^enter empty value in user name text box$")
	public void enter_empty_value_in_user_name_text_box() throws Throwable {
		fact.setuserName("");
		fact.setstore();

	}

	@Then("^print error message for name field$")
	public void print_error_message_for_name_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the city name$")
	public void check_the_city_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user enters empty value in the city name$")
	public void the_user_enters_empty_value_in_the_city_name() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("");
		fact.setstore();

	}

	@Then("^print error message for city field$")
	public void print_error_message_for_city_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check user password$")
	public void check_user_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^enter empty value in password text box$")
	public void enter_empty_value_in_password_text_box() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("");
		fact.setstore();
	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the gender$")
	public void check_the_gender() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user doesnt enter the gender$")
	public void the_user_doesnt_enter_the_gender() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setstore();
	}

	@Then("^print select any one option$")
	public void print_select_any_one_option() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the languages$")
	public void check_the_languages() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user doesnt select atleast one option$")
	public void the_user_doesnt_select_atleast_one_option() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setgender();
		fact.setstore();
	}

	@Then("^print error message for languages known$")
	public void print_error_message_for_languages_known() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the hidden$")
	public void check_the_hidden() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user lefts the hidden box empty$")
	public void the_user_lefts_the_hidden_box_empty() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setgender();
		fact.setlang();
		fact.setHidden("");
		fact.setstore();
	}

	@Then("^print error message for hidden$")
	public void print_error_message_for_hidden() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}
	@Given("^check the My number$")
	public void check_the_My_number() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user doesnt enter the number$")
	public void the_user_doesnt_enter_the_number() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setgender();
		fact.setlang();
		fact.setHidden(" Hello ");
		//fact.setEmail("gvash@gmail.com");
		fact.setNumber("");
		fact.setstore();
	}

	@Then("^print error message for My number$")
	public void print_error_message_for_My_number() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the email$")
	public void check_the_country() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user doesnt enter the email$")
	public void the_user_doesnt_select_the_country() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setgender();
		fact.setlang();
		fact.setHidden(" Hello ");
		fact.setNumber("100");
		fact.setEmail("");
		fact.setstore();
	}

	@Then("^print error message for email$")
	public void print_error_message_for_country() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();     
	}



	@Given("^check the mobile number$")
	public void check_the_mobile_number() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");

	}

	@When("^the user doesnt enter the mobile number$")
	public void the_user_doesnt_enter_the_mobile_number() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setgender();
		fact.setlang();
		fact.setHidden(" Hello ");
		fact.setNumber("100");
		fact.setEmail("gvash@gmail.com");
		fact.setMobile("");
		fact.setstore();
	}

	@Then("^print error message for mobile number$")
	public void print_error_message_for_mobile_number() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check all the valid data$")
	public void check_all_the_valid_data() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\drives\\cd\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryLogin(driver);
		driver.get("D:\\new sts files\\BddLoginDemo\\pom.html");
	}

	@When("^user has entered all valid data$")
	public void user_has_entered_all_valid_data() throws Throwable {
		fact.setuserName("Garal");
		fact.setcity("Delhi");
		fact.setpassword("garalvash21");
		fact.setgender();
		fact.setlang();
		fact.setHidden(" Hello ");
		fact.setNumber("100");
		fact.setEmail("gvash@gmail.com");
		fact.setMobile("9810488455");
		fact.setstore();
	}

	@Then("^print success message$")
	public void print_success_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

}



