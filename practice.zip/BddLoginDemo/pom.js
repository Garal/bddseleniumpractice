function chkEmpty(){
	
	if (document.frm1.userName.value == "") {alert("Please Enter Your Name");}
	else if(document.frm1.city.value=="") {alert("Please Enter The City");}
	else if (document.frm1.password.value == "") {alert("Please Enter The Password");}
	else if (document.frm1.gender.value == "") {alert("Please Select A Gender");}
	else if (document.frm1.lang.value == "") {alert("Please Select Atleast One Language");}
	else if (document.frm1.hidden.value == "") {alert("Please Fill The Hidden Box");}
	else if (document.frm1.number.value == "") {alert("Please Select A Number");}
	else if (document.frm1.email.value == "") {alert("Please Enter Your Email Id");}
	else if (document.frm1.mobile.value == "") {alert("Please Enter Your Mobile Number");}
	
	
	else {
		alert(" Login Successfully !!");

			}
		}

alert(document.frm1.gender.value);